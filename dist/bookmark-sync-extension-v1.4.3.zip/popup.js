// Simplified popup for note-only bookmark saving with auto-close
const PopupState = {
  currentTab: null,
  countdownInterval: null,
  remainingTime: 2,
  userInteracted: false,
  isClosing: false
};

// Force close popup after maximum time regardless of other conditions
const forceCloseTimer = setTimeout(() => {
  console.log('Force closing popup after maximum time');
  window.close();
}, 3000); // 3 seconds maximum

// Update status message
const updateStatus = (message, type = 'default') => {
  const statusElement = document.getElementById('status');
  statusElement.textContent = message;
  statusElement.className = `status ${type}`;
};

// Create bookmark data with note
const createBookmarkData = async (tab, note = '') => {
  try {
    // Get enhanced page metadata from content script
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'getPageMetadata' });
    
    if (response && response.success) {
      return {
        title: tab.title,
        url: tab.url,
        tags: [],
        timestamp: new Date().toISOString(),
        favicon: tab.favIconUrl,
        note: note.trim(),
        textContent: response.data.textContent || '',
        primaryImage: response.data.primaryImage || null,
        description: response.data.description || '',
        keywords: response.data.keywords || [],
        suggestedTags: response.data.suggestedTags || [],
        author: response.data.author || null,
        publishedDate: response.data.publishedDate || null,
        siteName: response.data.siteName || null
      };
    }
  } catch (error) {
    console.warn('Could not extract enhanced metadata:', error);
  }
  
  // Fallback to basic bookmark data
  return {
    title: tab.title,
    url: tab.url,
    tags: [],
    timestamp: new Date().toISOString(),
    favicon: tab.favIconUrl,
    note: note.trim(),
    textContent: '',
    primaryImage: null,
    description: '',
    keywords: [],
    suggestedTags: [],
    author: null,
    publishedDate: null,
    siteName: null
  };
};

// Save bookmark via background script
const saveBookmark = async (tab, note = '') => {
  console.log('saveBookmark called with tab:', tab?.title, 'note:', note);
  
  try {
    if (!tab || !tab.url) {
      throw new Error('Invalid tab data');
    }
    
    const bookmarkData = await createBookmarkData(tab, note);
    console.log('Created bookmark data:', bookmarkData);
    
    // Save via background script
    console.log('Sending saveBookmark message to background script...');
    
    // Add timeout to detect if background script is not responding
    const messagePromise = chrome.runtime.sendMessage({
      action: 'saveBookmark',
      bookmarkData: bookmarkData
    });
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Background script timeout')), 5000);
    });
    
    const response = await Promise.race([messagePromise, timeoutPromise]);
    
    console.log('Received response from background script:', response);
    
    if (response && response.success) {
      console.log('Bookmark saved successfully!');
      updateStatus('Saved! ✓', 'success');
      return true;
    } else {
      console.log('Save failed:', response?.error || 'Unknown error');
      
      // Handle duplicate bookmark case
      if (response?.error && response.error.includes('already exists')) {
        console.log('Bookmark already exists, checking if we should add note');
        
        if (note.trim()) {
          console.log('Adding note to existing bookmark...');
          // Try to add note to existing bookmark
          const noteResponse = await chrome.runtime.sendMessage({
            action: 'addNoteToBookmark',
            url: bookmarkData.url,
            note: note.trim()
          });
          
          console.log('Add note response:', noteResponse);
          
          if (noteResponse && noteResponse.success) {
            updateStatus('Note added! ✓', 'success');
            return true;
          } else {
            console.error('Failed to add note:', noteResponse?.error);
            updateStatus('Error adding note', 'error');
            return false;
          }
        }
        updateStatus('Already saved', 'error');
        return true; // Still considered successful since bookmark exists
      } else {
        updateStatus('Error saving', 'error');
        return false;
      }
    }
  } catch (error) {
    console.error('Error in saveBookmark function:', error);
    updateStatus('Error saving', 'error');
    return false;
  }
};

// Start countdown timer
const startCountdown = () => {
  const countdownElement = document.getElementById('countdown-timer');
  
  if (!countdownElement) {
    console.error('Countdown element not found, forcing close');
    setTimeout(() => window.close(), 2000);
    return;
  }
  
  console.log('Starting countdown timer');
  
  PopupState.countdownInterval = setInterval(() => {
    PopupState.remainingTime--;
    console.log('Countdown:', PopupState.remainingTime);
    
    if (countdownElement) {
      countdownElement.textContent = PopupState.remainingTime;
    }
    
    if (PopupState.remainingTime <= 0) {
      console.log('Countdown finished, triggering auto-save');
      clearInterval(PopupState.countdownInterval);
      autoSaveAndClose();
    }
  }, 1000);
  
  // Backup timer to ensure popup closes even if interval fails
  setTimeout(() => {
    if (!PopupState.isClosing) {
      console.log('Backup timer triggered, forcing save and close');
      autoSaveAndClose();
    }
  }, 2500);
};

// Auto-save and close popup
const autoSaveAndClose = async () => {
  if (PopupState.isClosing) {
    return; // Already closing, prevent multiple calls
  }
  
  PopupState.isClosing = true;
  console.log('Auto-save triggered, user interacted:', PopupState.userInteracted);
  
  // Clear any existing intervals
  if (PopupState.countdownInterval) {
    clearInterval(PopupState.countdownInterval);
  }
  
  const noteInput = document.getElementById('note-input');
  const note = noteInput ? noteInput.value.trim() : '';
  
  updateStatus('Saving...', 'loading');
  
  try {
    // Always save the bookmark (whether user interacted or not)
    console.log('Saving bookmark with note:', note);
    await saveBookmark(PopupState.currentTab, note);
    
    console.log('Bookmark saved, closing popup');
  } catch (error) {
    console.error('Error in auto-save:', error);
    updateStatus('Error, closing...', 'error');
  }
  
  // Always close popup after saving (or error)
  setTimeout(() => {
    console.log('Closing popup window');
    window.close();
  }, 300); // Reduced delay for faster closing
};

// Handle user interaction
const handleUserInteraction = () => {
  if (!PopupState.userInteracted) {
    PopupState.userInteracted = true;
    console.log('User interaction detected');
    
    // Update countdown display but don't stop the timer completely
    const countdownElement = document.getElementById('countdown');
    if (countdownElement) {
      countdownElement.textContent = 'Typing... (will save in a moment)';
      countdownElement.style.color = '#2563eb';
    }
  }
};

// Initialize popup
const initializePopup = async () => {
  console.log('Initializing popup...');
  
  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    PopupState.currentTab = tab;
    console.log('Current tab:', tab.title, tab.url);
    
    // Display page title (truncated)
    const titleElement = document.getElementById('page-title');
    if (titleElement) {
      titleElement.textContent = tab.title || 'Untitled';
    }
    
    // Start countdown
    console.log('Starting countdown...');
    startCountdown();
    
  } catch (error) {
    console.error('Error initializing popup:', error);
    updateStatus('Error loading', 'error');
    
    // Still try to close after a delay even if initialization fails
    setTimeout(() => {
      console.log('Closing popup after initialization error');
      window.close();
    }, 2000);
  }
};

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, setting up event listeners');
  
  const noteInput = document.getElementById('note-input');
  
  if (!noteInput) {
    console.error('Note input not found!');
    // Force close if elements are missing
    setTimeout(() => window.close(), 2000);
    return;
  }
  
  // Handle input events
  noteInput.addEventListener('input', handleUserInteraction);
  noteInput.addEventListener('focus', handleUserInteraction);
  
  // Handle Enter key to save immediately
  noteInput.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      console.log('Enter key pressed, saving immediately');
      
      // Clear timers to prevent double execution
      if (PopupState.countdownInterval) {
        clearInterval(PopupState.countdownInterval);
      }
      clearTimeout(forceCloseTimer);
      
      const note = noteInput.value.trim();
      updateStatus('Saving...', 'loading');
      
      try {
        await saveBookmark(PopupState.currentTab, note);
        
        setTimeout(() => {
          console.log('Closing after manual save');
          window.close();
        }, 300);
      } catch (error) {
        console.error('Error saving on Enter:', error);
        window.close();
      }
    }
  });
  
  // Handle Escape key to close immediately
  document.addEventListener('keyup', (e) => {
    if (e.key === 'Escape') {
      console.log('Escape key pressed, closing popup');
      // Clear all timers
      if (PopupState.countdownInterval) {
        clearInterval(PopupState.countdownInterval);
      }
      clearTimeout(forceCloseTimer);
      window.close();
    }
  });
  
  // Close popup when it loses focus (user clicks outside)
  window.addEventListener('blur', () => {
    console.log('Popup lost focus');
    setTimeout(() => {
      if (!PopupState.isClosing) {
        console.log('Triggering auto-save due to blur');
        autoSaveAndClose();
      }
    }, 100);
  });
  
  // Initialize the popup
  initializePopup();
});
