#!/bin/bash

# Test script for Auto-Save Popup functionality
# This script helps verify that the extension works correctly

echo "🔖 Bookmarkable Extension - Auto-Save Popup Test Suite"
echo "======================================================"
echo ""

echo "📋 Pre-Test Setup:"
echo "1. Make sure Chrome is installed and running"
echo "2. Load the extension in Chrome (chrome://extensions/)"
echo "3. Enable 'Developer mode' and click 'Load unpacked'"
echo "4. Select the extension folder: $(pwd)"
echo ""

echo "🧪 Test Cases to Execute:"
echo ""

echo "Test 1: Basic Auto-Save Functionality"
echo "-----------------------------------"
echo "Steps:"
echo "1. Open: http://localhost:8080/test-autosave-popup.html"
echo "2. Click the Bookmarkable extension icon"
echo "3. Wait for popup to appear (should show 'Auto-save in 1s...')"
echo "4. DO NOT click any buttons - just wait"
echo "5. Popup should auto-close and save bookmark"
echo "Expected: Bookmark saved automatically"
echo ""

echo "Test 2: User Interaction Prevention"
echo "---------------------------------"
echo "Steps:"
echo "1. Refresh the test page"
echo "2. Click the extension icon"
echo "3. Immediately click 'Save Bookmark' button"
echo "4. Verify status changes from 'Auto-save in 1s...' to 'Ready'"
echo "Expected: No duplicate bookmarks created"
echo ""

echo "Test 3: Duplicate Detection"
echo "-------------------------"
echo "Steps:"
echo "1. Ensure the test page is already bookmarked"
echo "2. Click extension icon again"
echo "3. Let auto-save trigger"
echo "4. Should detect existing bookmark"
echo "Expected: Proper duplicate handling"
echo ""

echo "🚀 Starting test server..."
echo "Server running at: http://localhost:8080"
echo "Test page: http://localhost:8080/test-autosave-popup.html"
echo ""

# Check if server is already running
if lsof -i:8080 > /dev/null 2>&1; then
    echo "✅ Server is already running on port 8080"
else
    echo "❌ Server not detected on port 8080"
    echo "Please run: python3 -m http.server 8080"
fi

echo ""
echo "🔍 Extension Loading Instructions:"
echo "1. Open Chrome and go to chrome://extensions/"
echo "2. Enable 'Developer mode' (toggle in top right)"
echo "3. Click 'Load unpacked' button"
echo "4. Select this directory: $(pwd)"
echo "5. The extension should appear in your extensions list"
echo ""

echo "📊 Manual Verification Steps:"
echo "1. Look for 'Auto-save in 1s...' message in popup status"
echo "2. Check that status changes when you interact with buttons"
echo "3. Verify bookmarks are saved in extension's bookmark manager"
echo "4. Test on multiple different web pages"
echo ""

echo "🐛 Troubleshooting:"
echo "- If popup doesn't show auto-save message, check console for errors"
echo "- If bookmarks aren't saved, check background script console"
echo "- If server isn't running, start it with: python3 -m http.server 8080"
echo ""

echo "Ready for testing! 🎯"